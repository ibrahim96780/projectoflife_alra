
import React from 'react';
import type { VideoContent } from '../types';
import VideoCard from './VideoCard';

interface ContentCarouselProps {
  title: string;
  videos: VideoContent[];
}

const ContentCarousel: React.FC<ContentCarouselProps> = ({ title, videos }) => {
  return (
    <section className="mb-8">
      <h2 className="text-2xl font-bold text-light-text mb-4 px-4">{title}</h2>
      <div className="flex overflow-x-auto space-x-4 pb-4 px-4 scrollbar-hide">
        {videos.map((video) => (
          <div key={video.id} className="flex-shrink-0 w-64 md:w-80">
            <VideoCard video={video} />
          </div>
        ))}
      </div>
    </section>
  );
};

// A little helper CSS to hide scrollbars where supported
const style = document.createElement('style');
style.innerHTML = `
  .scrollbar-hide::-webkit-scrollbar {
    display: none;
  }
  .scrollbar-hide {
    -ms-overflow-style: none;
    scrollbar-width: none;
  }
`;
document.head.appendChild(style);


export default ContentCarousel;