import React from 'react';
import { MOCK_VIDEO_CONTENT } from '../constants';
import VideoCard from './VideoCard';
import type { VideoContent } from '../types';

const DiscoursesPage: React.FC = () => {
  const allVideos: VideoContent[] = [
    ...MOCK_VIDEO_CONTENT.trending,
    ...MOCK_VIDEO_CONTENT.upcoming,
  ];

  return (
    <div className="px-4">
      <h1 className="text-3xl font-bold text-light-text mb-6">All Discourses</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {allVideos.map((video) => (
          <VideoCard key={video.id} video={video} />
        ))}
      </div>
    </div>
  );
};

export default DiscoursesPage;
