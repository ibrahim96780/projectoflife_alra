import React from 'react';
import { HomeIcon, DiscoursesIcon, LiveIcon, ProfileIcon } from './IconComponents';

interface FooterNavProps {
    activeTab: string;
    onTabChange: (tab: string) => void;
}

const FooterNav: React.FC<FooterNavProps> = ({ activeTab, onTabChange }) => {
  const navItems = [
    { icon: HomeIcon, label: 'Home' },
    { icon: DiscoursesIcon, label: 'Discourses' },
    { icon: LiveIcon, label: 'Live' },
    { icon: ProfileIcon, label: 'Profile' },
  ];

  return (
    <footer className="fixed bottom-0 left-0 right-0 bg-light-bg border-t border-gray-200 z-40">
      <div className="container mx-auto px-4 h-16 flex justify-around items-center">
        {navItems.map((item, index) => (
          <button 
            key={index}
            onClick={() => onTabChange(item.label)}
            className={`flex flex-col items-center gap-1 w-20 transition-colors ${activeTab === item.label ? 'text-brand-red' : 'text-light-text-secondary hover:text-light-text'}`}
            aria-current={activeTab === item.label ? 'page' : undefined}
          >
            <item.icon className="w-6 h-6" />
            <span className="text-xs font-medium">{item.label}</span>
          </button>
        ))}
      </div>
    </footer>
  );
};

export default FooterNav;