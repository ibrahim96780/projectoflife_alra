import React from 'react';
import { AlraTVLogo, ProfileIcon, HeartIcon } from './IconComponents';

const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 bg-light-bg/80 backdrop-blur-sm border-b border-gray-200 z-40">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center gap-2">
            <AlraTVLogo className="w-28 h-10 text-brand-red" />
        </div>
        <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-brand-red hover:bg-brand-red/90 transition-colors">
                <HeartIcon className="w-5 h-5 text-white" />
                <span className="text-sm font-semibold text-white">Donate</span>
            </button>
            <button className="p-2 rounded-full hover:bg-light-surface">
                <ProfileIcon className="w-6 h-6 text-light-text" />
            </button>
        </div>
      </div>
    </header>
  );
};

export default Header;