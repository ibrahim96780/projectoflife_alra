
import React, { useState, useEffect, useRef } from 'react';
import type { ChatMessage, Language } from '../types';
import { SendIcon } from './IconComponents';
import { translateText } from '../services/geminiService';

interface LiveChatProps {
    currentLanguage: Language;
}

const LiveChat: React.FC<LiveChatProps> = ({ currentLanguage }) => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [newMessage, setNewMessage] = useState('');
    const chatEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);
    
    // Simulate receiving messages from other users
    useEffect(() => {
        const mockMessages = [
            { user: 'Alex', text: 'This is amazing!' },
            { user: 'Yuki', text: '本当にすごい！' },
            { user: 'Maria', text: '¡Increíble presentación!' },
        ];

        const interval = setInterval(() => {
            const randomMsg = mockMessages[Math.floor(Math.random() * mockMessages.length)];
            const newId = messages.length + Date.now();
            const incomingMessage: ChatMessage = {
                id: newId,
                user: randomMsg.user,
                originalText: randomMsg.text,
                isMe: false,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            };
            
            setMessages(prev => [...prev, incomingMessage]);
            
            translateText(randomMsg.text, currentLanguage.code).then(translated => {
                setMessages(prev => prev.map(m => m.id === newId ? { ...m, translatedText: translated } : m));
            });

        }, 12000); // Increased interval to reduce API call frequency

        return () => clearInterval(interval);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currentLanguage.code]);

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim() === '') return;

        const myMessage: ChatMessage = {
            id: messages.length + Date.now(),
            user: 'You',
            originalText: newMessage,
            translatedText: newMessage, // No need to translate my own message
            isMe: true,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages([...messages, myMessage]);
        setNewMessage('');
    };

    return (
        <div className="bg-light-bg rounded-lg flex flex-col h-full max-h-[calc(100vh-100px)] md:max-h-full border border-gray-200 shadow-sm">
            <h3 className="text-lg font-bold text-light-text p-4 border-b border-gray-200">Live Chat</h3>
            <div className="flex-grow p-4 overflow-y-auto bg-light-surface/50">
                <div className="space-y-4">
                    {messages.map((msg) => (
                        <div key={msg.id} className={`flex flex-col ${msg.isMe ? 'items-end' : 'items-start'}`}>
                            <div className={`p-3 rounded-lg max-w-xs md:max-w-md shadow-sm ${msg.isMe ? 'bg-brand-red text-white rounded-br-none' : 'bg-white text-light-text rounded-bl-none border border-gray-200'}`}>
                                {!msg.isMe && <p className="font-bold text-brand-red text-sm">{msg.user}</p>}
                                <p className="text-sm">{msg.translatedText || 'Translating...'}</p>
                                {!msg.isMe && msg.translatedText && <p className="text-xs text-gray-500 italic mt-1 opacity-75">Original: {msg.originalText}</p>}
                            </div>
                            <span className="text-xs text-light-text-secondary mt-1 px-1">{msg.timestamp}</span>
                        </div>
                    ))}
                </div>
                <div ref={chatEndRef} />
            </div>
            <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-200">
                <div className="flex items-center gap-2">
                    <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Say something..."
                        className="w-full bg-light-surface text-light-text placeholder-gray-500 rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-brand-red"
                    />
                    <button type="submit" className="bg-brand-red text-white p-2.5 rounded-full hover:bg-brand-red/90 transition-colors disabled:opacity-50" disabled={!newMessage.trim()}>
                        <SendIcon className="w-5 h-5" />
                    </button>
                </div>
            </form>
        </div>
    );
};

export default LiveChat;