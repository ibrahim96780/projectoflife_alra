
import React, { useState, useEffect, useRef } from 'react';
import type { Language } from '../types';
import { LIVE_STREAM_SCRIPT } from '../constants';
import { translateTextArray } from '../services/geminiService';
import LanguageSelector from './LanguageSelector';

interface LivePlayerProps {
    currentLanguage: Language;
    onLanguageChange: (language: Language) => void;
}

const LivePlayer: React.FC<LivePlayerProps> = ({ currentLanguage, onLanguageChange }) => {
    const [displayedTranscript, setDisplayedTranscript] = useState<string[]>([]);
    const [fullTranslatedScript, setFullTranslatedScript] = useState<string[]>([]);
    const [currentLineIndex, setCurrentLineIndex] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const transcriptEndRef = useRef<HTMLDivElement>(null);
    const streamIntervalRef = useRef<number | null>(null);

    // Effect 1: Translate the entire script at once when the language changes.
    useEffect(() => {
        let isCancelled = false;

        const fetchAndTranslateScript = async () => {
            setIsLoading(true);
            setDisplayedTranscript([]);
            setCurrentLineIndex(0);
            if (streamIntervalRef.current) clearInterval(streamIntervalRef.current);

            // If the target language is English, use the original script.
            if (currentLanguage.code === 'en') {
                if (!isCancelled) {
                    setFullTranslatedScript(LIVE_STREAM_SCRIPT);
                    setIsLoading(false);
                }
                return;
            }

            const translatedLines = await translateTextArray(LIVE_STREAM_SCRIPT, currentLanguage.name);
            if (!isCancelled) {
                setFullTranslatedScript(translatedLines);
                setIsLoading(false);
            }
        };

        fetchAndTranslateScript();

        return () => {
            isCancelled = true;
        };
    }, [currentLanguage]);

    // Effect 2: "Stream" the pre-translated lines to the screen.
    useEffect(() => {
        if (isLoading || fullTranslatedScript.length === 0) {
            return; // Don't start streaming until we have the translated script
        }

        if (streamIntervalRef.current) clearInterval(streamIntervalRef.current);

        streamIntervalRef.current = window.setInterval(() => {
            setCurrentLineIndex(prevIndex => {
                const nextIndex = prevIndex + 1;
                if (nextIndex > fullTranslatedScript.length) {
                    if (streamIntervalRef.current) clearInterval(streamIntervalRef.current);
                    return prevIndex;
                }
                return nextIndex;
            });
        }, 6000); // New line every 6 seconds

        return () => {
            if (streamIntervalRef.current) clearInterval(streamIntervalRef.current);
        };
    }, [isLoading, fullTranslatedScript]);

    // Effect 3: Update the displayed transcript when the current line index changes.
    useEffect(() => {
        if (currentLineIndex > 0) {
            setDisplayedTranscript(fullTranslatedScript.slice(0, currentLineIndex));
        }
    }, [currentLineIndex, fullTranslatedScript]);

    // Effect 4: Scroll to bottom as new lines are added.
    useEffect(() => {
        transcriptEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [displayedTranscript]);

    return (
        <div className="bg-light-bg rounded-lg overflow-hidden shadow-lg border border-gray-200 flex flex-col h-full">
            <div className="relative aspect-video bg-gray-900 flex items-center justify-center">
                <img src="https://picsum.photos/seed/spirit/1280/720" alt="Live Stream" className="w-full h-full object-cover"/>
                <div className="absolute inset-0 bg-black bg-opacity-40"></div>
                <div className="absolute top-4 left-4 bg-brand-red text-white px-3 py-1 text-sm font-bold rounded-md flex items-center gap-2">
                    <span className="relative flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                    </span>
                    LIVE
                </div>
                <div className="absolute bottom-4 left-0 right-0 p-4 text-white text-center z-10">
                    <div className="bg-black bg-opacity-50 p-4 rounded-lg">
                        <h2 className="text-xl md:text-2xl font-bold">Sufi Master Younus AlGohar's Daily Discourse</h2>
                    </div>
                </div>
            </div>
            <div className="flex-grow bg-light-bg p-4 flex flex-col">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold text-light-text">Live Transcript ({currentLanguage.name})</h3>
                    <LanguageSelector selectedLanguage={currentLanguage} onLanguageChange={onLanguageChange} />
                </div>
                <div className="flex-grow bg-light-surface rounded-md p-4 overflow-y-auto text-light-text text-lg leading-relaxed space-y-4">
                    {displayedTranscript.map((line, index) => (
                        <p key={index}>{line}</p>
                    ))}
                    {isLoading && <p className="text-light-text-secondary animate-pulse">Translating discourse...</p>}
                    {!isLoading && currentLineIndex < fullTranslatedScript.length && <p className="text-light-text-secondary animate-pulse">...</p>}
                    <div ref={transcriptEndRef} />
                </div>
            </div>
        </div>
    );
};

export default LivePlayer;