import React from 'react';
import { ProfileIcon } from './IconComponents';

const ProfilePage: React.FC = () => {
  return (
    <div className="px-4 text-center flex flex-col items-center justify-center h-[60vh]">
      <ProfileIcon className="w-24 h-24 text-light-text-secondary mb-4" />
      <h1 className="text-3xl font-bold text-light-text mb-2">Profile</h1>
      <p className="text-light-text-secondary max-w-md">
        This is your personal profile page. Account settings, viewing history, and other personalized features will be available here in a future update.
      </p>
      <button className="mt-6 bg-brand-red text-white font-bold py-2 px-6 rounded-lg hover:bg-brand-red/90 transition-colors">
        Log Out
      </button>
    </div>
  );
};

export default ProfilePage;
