import React, { useState } from 'react';
import type { VideoContent } from '../types';
import { InfoIcon } from './IconComponents';
import { summarizeText } from '../services/geminiService';

interface VideoCardProps {
  video: VideoContent;
}

const SummaryModal: React.FC<{ summary: string; onClose: () => void; title: string }> = ({ summary, onClose, title }) => (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-light-bg rounded-lg shadow-xl p-6 max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-xl font-bold text-light-text mb-2">{title} - AI Summary</h3>
        <div className="text-light-text-secondary whitespace-pre-wrap max-h-[60vh] overflow-y-auto bg-light-surface p-4 rounded-md">{summary}</div>
        <button onClick={onClose} className="mt-4 bg-brand-red text-white font-bold py-2 px-4 rounded-lg w-full hover:bg-brand-red/90 transition-colors">Close</button>
      </div>
    </div>
);


const VideoCard: React.FC<VideoCardProps> = ({ video }) => {
  const [showSummary, setShowSummary] = useState(false);
  const [summary, setSummary] = useState('');
  const [isSummarizing, setIsSummarizing] = useState(false);
  
  const handleGetSummary = async (event: React.MouseEvent) => {
    event.stopPropagation();
    event.preventDefault();
    setIsSummarizing(true);
    // In a real app, you would fetch the full transcript for the video.
    // Here we use a mock transcript based on video details for demonstration.
    const fakeTranscript = `This is a recorded discourse titled "${video.title}". The main topic is ${video.description}. The discourse explains profound spiritual concepts, provides historical context, and guides the listener on the path of spiritual enlightenment. Key themes include divine love, the nature of the soul, and the importance of a spiritual guide.`;
    const result = await summarizeText(fakeTranscript);
    setSummary(result);
    setIsSummarizing(false);
    setShowSummary(true);
  };

  return (
    <>
      <div className="bg-light-bg border border-gray-200 rounded-lg overflow-hidden group shadow-sm hover:shadow-lg transition-shadow">
        <div className="relative">
          <img src={video.thumbnailUrl} alt={video.title} className="w-full aspect-video object-cover" />
          <div className="absolute inset-0 bg-black bg-opacity-10 group-hover:bg-opacity-30 transition-all"></div>
          {video.type === 'upcoming' && <div className="absolute top-2 right-2 bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded">UPCOMING</div>}
          {video.duration && <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs font-bold px-2 py-1 rounded">{video.duration}</div>}
           {video.type === 'replay' && (
             <button 
                onClick={handleGetSummary}
                disabled={isSummarizing}
                className="absolute top-2 left-2 bg-brand-red text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all disabled:opacity-50 disabled:animate-pulse"
                title="Get AI Summary"
              >
               <InfoIcon className="w-5 h-5"/>
             </button>
           )}
        </div>
        <div className="p-3">
          <h4 className="text-light-text font-bold truncate">{video.title}</h4>
          <p className="text-light-text-secondary text-sm truncate">{video.description}</p>
        </div>
      </div>
      {showSummary && <SummaryModal summary={isSummarizing ? "Generating..." : summary} onClose={() => setShowSummary(false)} title={video.title} />}
    </>
  );
};

export default VideoCard;