import type { Language, VideoContent } from './types';

export const SUPPORTED_LANGUAGES: Language[] = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'hi', name: 'Hindi' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ur', name: 'Urdu' },
  { code: 'ar', name: 'Arabic' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ru', name: 'Russian' },
];

export const MOCK_VIDEO_CONTENT: { [key: string]: VideoContent[] } = {
  featured: [
    {
      id: 1,
      title: 'Sufi Master Younus AlGohar\'s Daily Discourse',
      description: 'Join us live for tonight\'s spiritual discourse, broadcast worldwide.',
      thumbnailUrl: 'https://picsum.photos/seed/spirit/800/450',
      type: 'live',
    }
  ],
  trending: [
    { id: 2, title: 'Karbala: Hussainiyat vs Yazeediyat', description: 'A historical and spiritual analysis.', thumbnailUrl: 'https://picsum.photos/seed/karbala/400/225', type: 'replay', duration: '1hr 15min' },
    { id: 3, title: 'The Reality of Naad-e-Ali', description: 'Unlocking the secrets of the powerful prayer.', thumbnailUrl: 'https://picsum.photos/seed/prayer/400/225', type: 'replay', duration: '55min' },
    { id: 4, title: 'The Path to Divine Love', description: 'A series on the core tenets of Sufism.', thumbnailUrl: 'https://picsum.photos/seed/love/400/225', type: 'replay', duration: '1hr 2min' },
  ],
  upcoming: [
    { id: 5, title: 'Special Event: The Night of Ascension', description: 'Commemorating the miraculous journey.', thumbnailUrl: 'https://picsum.photos/seed/night/400/225', type: 'upcoming' },
    { id: 6, title: 'Q&A with Sufi Master Younus AlGohar', description: 'An interactive session with our global audience.', thumbnailUrl: 'https://picsum.photos/seed/qa/400/225', type: 'upcoming' },
    { id: 7, title: 'The Universal Message of All Religions', description: 'A discourse on spiritual unity.', thumbnailUrl: 'https://picsum.photos/seed/unity/400/225', type: 'upcoming' },
  ],
};

export const LIVE_STREAM_SCRIPT: string[] = [
    "Welcome, seekers of truth, to our global congregation.",
    "Tonight, we delve into the ocean of spirituality, to find the pearls of divine wisdom.",
    "The heart is not just an organ; it is the seat of the divine presence within you.",
    "To connect with God, you must first connect with your own heart.",
    "This journey inwards is the essence of the spiritual path taught by all prophets and saints.",
    "Let go of the ego, the 'I', which creates a veil between you and the ultimate reality.",
    "Through meditation and remembrance, we polish the mirror of the heart.",
    "When this mirror is clean, it reflects the light of the divine, illuminating your entire being.",
    "This is not a concept to be understood by the mind, but a reality to be experienced in the soul.",
    "Open your hearts to receive this grace, which flows endlessly from the source of all existence.",
    "The path is simple, but the journey requires sincerity and perseverance.",
    "May we all be guided on this sacred path towards unity and divine love.",
    "Thank you for joining us. Peace be upon you all."
];