
import { GoogleGenAI, Type } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const translateText = async (text: string, targetLanguage: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Translate the following text to ${targetLanguage}: "${text}"`,
            config: {
                temperature: 0.3,
                // Disable thinking for faster translation response
                thinkingConfig: { thinkingBudget: 0 }
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error('Error translating text:', error);
        return `Error: Could not translate to ${targetLanguage}.`;
    }
};

export const translateTextArray = async (texts: string[], targetLanguage: string): Promise<string[]> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Translate each string in the following JSON array of strings to ${targetLanguage}. Return a JSON array of the translated strings. The order and number of strings in the output array must be the same as the input array.\n\nInput:\n${JSON.stringify(texts)}`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                },
                thinkingConfig: { thinkingBudget: 0 }
            }
        });
        
        const jsonResponse = JSON.parse(response.text);
        if (Array.isArray(jsonResponse) && jsonResponse.every(item => typeof item === 'string')) {
            return jsonResponse;
        } else {
            console.error("Translated response is not a string array:", jsonResponse);
            return texts.map(() => `Error: Translation format incorrect for ${targetLanguage}.`);
        }

    } catch (error) {
        console.error('Error translating text array:', error);
        return texts.map(() => `Error: Could not translate to ${targetLanguage}.`);
    }
};


export const summarizeText = async (text: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Provide a concise, bullet-point summary of the following transcript:\n\n---\n\n${text}`,
        });
        return response.text.trim();
    } catch (error) {
        console.error('Error summarizing text:', error);
        return "Error: Could not generate summary.";
    }
};
