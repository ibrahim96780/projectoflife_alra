
export interface Language {
  code: string;
  name: string;
}

export interface VideoContent {
  id: number;
  title: string;
  description: string;
  thumbnailUrl: string;
  type: 'live' | 'replay' | 'upcoming';
  duration?: string;
}

export interface ChatMessage {
    id: number;
    user: string;
    originalText: string;
    translatedText?: string;
    isMe: boolean;
    timestamp: string;
}
